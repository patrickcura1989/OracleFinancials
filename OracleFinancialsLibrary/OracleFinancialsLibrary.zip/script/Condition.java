
public interface Condition {
	
	public boolean isReady();

}
