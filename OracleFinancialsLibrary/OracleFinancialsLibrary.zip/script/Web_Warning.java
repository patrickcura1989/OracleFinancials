
public interface Web_Warning {
	static final String NO_BUTTON  = "" ;
	static final String YES_BUTTON = "" ;
	

}
