
public interface Forms_Distributions {
	 static String FORM_NAME = "DIST_SUMMARY";
	 static String DISTRIBUTIONS_AMOUNT = "//forms:textField[(@name='D_SUM_FOLDER_AMOUNT_%')]";
	 static String DISTRIBUTIONS_ACCOUNT = "//forms:textField[(@name='D_SUM_FOLDER_DIST_CODE_COMBINATION_DISP_%')]";
}
