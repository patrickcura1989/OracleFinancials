
public interface Forms_Invoice_Overview {
   static final String PAYMENT_OVERVIEW = "//forms:button[(@name='INVOICE_PAYMENTS_BUTTON_%')]" ;
   static final String PAID_BY = "//forms:textField[(@name='PAYMENT_SCHEDULES_PAID_BY_%')]" ;
   static final String PAID_ON = "//forms:textField[(@name='PAYMENT_SCHEDULES_PAID_DATE_%')]" ;
}
