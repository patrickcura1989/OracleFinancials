
public interface Forms_Installments {
	static String TITLE = "CQIT_PS";
}
