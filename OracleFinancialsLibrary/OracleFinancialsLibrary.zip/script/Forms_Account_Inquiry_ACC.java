
public interface Forms_Account_Inquiry_ACC {
   static final String 	ACCOUNTING = "//forms:textField[(@name='FLEX_ACCOUNTING_FLEXFIELD_%')]";   
   static final String SHOW_FULL_JOURNAL_BTN = "//forms:button[(@name='CONTROL_SHOW_JOURNALS_0')]" ;
   static final String DRILL_DOWN = "//forms:button[(@name='FOLDER_JOURNAL_SUBLEDGER_0')]" ;
}
