
public interface Forms_Collections {
	 static String VIEW_LIST = "IEXCUOVW_HEADER_VIEW_BY_TYPE_0";
	 static String VIEW_TEXT_FIELD = "//forms:textField[(@name='IEXCUOVW_HEADER_ACCOUNT_NUMBER_0')]";
	 static String TAB_CONTAINER = "IEXRCALL_TAB";
	 
	 static String STRATEGY_TABLE_1 = "//forms:spreadTable[(@name='IEXSTTAB_STRATEGY_STRATEGY_GRID_0')]";
	 static String STRATEGY_TABLE_2 = "//forms:spreadTable[(@name='IEXSTTAB_WKITEM_WKITEM_GRID_0')]";
	 
	 static String STRATEGY_COMPLETE_BUTTON = "//forms:button[(@name='IEXSTTAB_CONTROL_COMPLETE_WORK_0')]";
}
