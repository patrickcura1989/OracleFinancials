
public interface Forms_Adjustments {
	static String TITLE = "ADJ_ADJUST";
	static String ACTIVITY_NAME = "//forms:textField[(@name='ADJ_ADJUST_ACTIVITY_NAME_%')]";	
	static String AMOUNT = "//forms:textField[(@name='ADJ_ADJUST_AMOUNT_%')]";
	static String AMOUNT_DUE_REMAINING = "//forms:textField[(@name='ADJ_CONTEXT_AMOUNT_DUE_REMAINING_0')]";
	
}
