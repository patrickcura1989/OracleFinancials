
public interface Web_SearchSupplierBankAccount {
    static final  String SUPPLIER_NUMBER = "" ;
    static final  String GO_BUTTON = "" ;
    static final  String HOME_LINK = "" ;
}
