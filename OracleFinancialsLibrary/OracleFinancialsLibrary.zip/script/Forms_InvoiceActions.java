
public interface Forms_InvoiceActions {
	 static final String APPROVE_CHECKBOX = "//forms:checkBox[(@name='INV_SUM_ACTIONS_APPROVE_0')]";	
	 static final String OK_BUTTON = "//forms:button[(@name='INV_SUM_ACTIONS_OK_BUTTON_0')]";
}
