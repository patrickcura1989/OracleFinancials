
public interface Web_PaymentDetails {
	static final String UPDATE_PAYMENT_DETAILS_ICON = "/web:window[@title='Payment Details']/web:document[@index='0']/web:img[@alt='Update Payment Details' or @index='28' or @src='https://app-layer-oracleebs-test.ds.acc.co.nz:4475/OA_MEDIA/updateicon_enabled.gif']";
	static final String SAVE_BUTTON = "/web:window[@title='Payment Details']/web:document[@index='0']/web:form[@id='DefaultFormName' or @name='DefaultFormName' or @index='0']/web:button[@id='Apply' or @value='<SPAN class=xq Oracle_OS_WebDOM_ElementID=&quot;True&quot;>S</SPAN>ave' or @index='1']";
	static final String ADDRESS_BOOK_LINK = "/web:window[@title='Payment Details']/web:document[@index='0']/web:a[@text='Address Book' or @href=\"javascript:_submitNav(&apos;DefaultFormName&apos;,&apos;https%3A//app-layer-oracleebs-test.ds.acc.co.nz%3A4475/OA_HTML/OA.jsp%3Fpage%3D/oracle/apps/pos/supplier/webui/ByrAddrBkPG%26retainAM%3DY%26_ti%3D1583477783%26oapc%3D26%26OAMC%3D79928_67_0%26menu%3DY%26oaMenuLevel%3D4%26oas%3Da5M_Dcr_5g_RDfPx7mc5ug..&apos;)\" or @index='13']";
	static final String CANCEL_BUTTON = "";
    static final String HOME_LINK = "";
    static final String EDIT_ICON = "" ;
    static final String PAGE_NAME = "" ;
    static final String ELECTRONIC = "" ;
    static final String SEPARATE_REMITTANCE_ADVICE_DELIVERY = "" ;
    static final String DELIVERY_METHOD = "" ;
    static final String E_MAIL = "" ;
    
}
