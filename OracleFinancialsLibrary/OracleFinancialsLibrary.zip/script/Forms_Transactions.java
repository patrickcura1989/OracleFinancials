
public interface Forms_Transactions {
	static String SOURCE_NAME = "//forms:textField[(@name='TGW_HEADER_BS_BATCH_SOURCE_NAME_MIR_0')]";
	static String NUMBER = "//forms:textField[(@name='TGW_HEADER_TRX_NUMBER_MIR_0')]";
	static String CLASS = "TGW_HEADER_CTT_CLASS_MIR_0";
	static String TYPE = "//forms:textField[(@name='TGW_HEADER_CTT_TYPE_NAME_MIR_0')]";
	static String TRANSACTION = "//forms:textField[(@name='TGW_HEADER_TRANSACTION_FLEX_MIR_0')]";
	static String CUSTOMER_NUMBER = "//forms:textField[(@name='TGW_HEADER_RAC_BILL_TO_CUSTOMER_NUM_MIR_0')]";
	static String LINE_ITEMS_BUTTON = "//forms:button[(@name='TGW_HEADER_HEADER_LINE_ITEMS_0')]";
	static String COMPLETE_BUTTON = "//forms:button[(@name='TGW_HEADER_HEADER_COMPLETE_0')]";
	static String COMPLETE_CHECKBOX = "//forms:checkBox[(@name='TGW_HEADER_COMPLETE_FLAG_MIR_0')]";
	

}
