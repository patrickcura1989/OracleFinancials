
public interface Web_CreateUpdateAddress {
	static String ADDRESS_LINE_4 = "/web:window[@title='Create/Update Address']/web:document[@index='0']/web:form[@id='DefaultFormName' or @name='DefaultFormName' or @index='0']/web:input_text[@id='HzAddressStyleFlex4' or @name='HzAddressStyleFlex4' or @index='4']";
	static String APPLY_BUTTON = "/web:window[@title='Create/Update Address']/web:document[@index='0']/web:form[@id='DefaultFormName' or @name='DefaultFormName' or @index='0']/web:button[@id='applyBtn' or @value='A<SPAN class=xq Oracle_OS_WebDOM_ElementID=&quot;True&quot;>p</SPAN>ply' or @index='1']";
	static String ADDRESS_LINE_1 = "/web:window[@title='Create/Update Address']/web:document[@index='0']/web:form[@id='DefaultFormName' or @name='DefaultFormName' or @index='0']/web:input_text[@id='HzAddressStyleFlex1' or @name='HzAddressStyleFlex1' or @index='1']";
	static String ADDRESS_LINE_2 = "/web:window[@title='Create/Update Address']/web:document[@index='0']/web:form[@id='DefaultFormName' or @name='DefaultFormName' or @index='0']/web:input_text[@id='HzAddressStyleFlex2' or @name='HzAddressStyleFlex2' or @index='2']";
	static String TOWN_CITY = "/web:window[@title='Create/Update Address']/web:document[@index='0']/web:form[@id='DefaultFormName' or @name='DefaultFormName' or @index='0']/web:input_text[@id='HzAddressStyleFlex5' or @name='HzAddressStyleFlex5' or @index='5']";
	static String ADDRESS_NAME = "/web:window[@title='Create/Update Address']/web:document[@index='0']/web:form[@id='DefaultFormName' or @name='DefaultFormName' or @index='0']/web:input_text[@id='hzPartySiteName' or @name='hzPartySiteName' or @index='7']";
	static String CONTINUE_BUTTON = "/web:window[@title='Create/Update Address']/web:document[@index='0']/web:form[@id='DefaultFormName' or @name='DefaultFormName' or @index='0']/web:button[@id='nextBtn_uixr' or @value='<SPAN class=xq Oracle_OS_WebDOM_ElementID=&quot;True&quot;>C</SPAN>ontinue' or @index='3']";
	
}
