
public interface Web_SupplierApproval {
	public static final String APPROVE_BUTTON = "/web:window[@title='Notification Details']/web:document[@index='0']/web:form[@id='DefaultFormName' or @name='DefaultFormName' or @index='0']/web:button[@value='Approve' or @index='4']";	
}
