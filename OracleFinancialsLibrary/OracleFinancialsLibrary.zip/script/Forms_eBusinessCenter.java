
public interface Forms_eBusinessCenter {
	static String NAME = "ASTRCALL_MAIN";
	static String TABS = "CSC_CUSTOMER_RESPONSE_TAB";
	static String NOTES_NEW_BUTTON = "//forms:button[(@name='NOTE_CONTROL_NEW_0')]";	
	static String NOTES_DETAILS = "//forms:textField[(@name='NOTE_DETAILS_NOTES_0')]";
}
