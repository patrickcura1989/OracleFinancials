
public class TimeOutException extends RuntimeException {
		
	private static final long serialVersionUID = 1L;

	public TimeOutException (){
		super("Operation Timeout");
	}

}
