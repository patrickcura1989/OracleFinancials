
public interface Web_Customers {
	static String CREATE_BUTTON = "/web:window[@index='2' or @title='Customers']/web:document[@index='0']/web:form[@id='DefaultFormName' or @name='DefaultFormName' or @index='0']/web:button[@id='HzPuiCreate' or @value='Create' or @index='2']";
	static String PARTY_NUMBER = "/web:window[@index='2' or @title='Customers']/web:document[@index='0']/web:form[@id='DefaultFormName' or @name='DefaultFormName' or @index='0']/web:input_text[@id='RegistryID' or @name='RegistryID' or @index='1']";
	static String GO_BUTTON = "/web:window[@index='2' or @title='Customers']/web:document[@index='0']/web:form[@id='DefaultFormName' or @name='DefaultFormName' or @index='0']/web:button[@id='HzPuiGoSearch' or @value='Go' or @index='0']";
	static String LINK_1 = "/web:window[@index='2' or @title='Customers']/web:document[@index='0']/web:a[@text='The H & J Rothfield Family Tst' or @href=\"https://app-layer-oracleebs-test.ds.acc.co.nz:4476/OA_HTML/OA.jsp?page=/oracle/apps/ar/cusstd/srch/webui/ArPrtySrchPG&OAHP=AR_CUS_STD_ROOT&OASF=AR_CUS_SRCH&_ti=473468976&language_code=US&CallFromForm=&apos;Y&apos;&oapc=6&oas=5rtwt28N18gMQNWHRuVECQ..#\" or @index='18']";
}
