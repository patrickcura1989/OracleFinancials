
public interface Web_Search_And_Select_Values {
    static final String CORPORATE = "" ;
    static final String SELECT_BUTTON = "" ;
}
