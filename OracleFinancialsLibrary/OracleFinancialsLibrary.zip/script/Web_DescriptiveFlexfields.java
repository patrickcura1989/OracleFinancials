
public interface Web_DescriptiveFlexfields {
	static final String PAGE_NAME = "/web:window[@title='Descriptive Flexfields']" ;
	static final String APPROVAL_STATUS = "/web:window[@title='Descriptive Flexfields']/web:document[@index='0']/web:form[@id='DefaultFormName']/web:input_text[@id='DFFlex1']" ;
	static final String APPLY_BUTTON =  PAGE_NAME + "/web:document[@index='0']/web:form[@id='DefaultFormName']/web:button[@id='applyBtn']" ;
}
