
public interface Forms_Find_Key_Flexfield_Segment {
	static String FIND_VALUES_BY_VALUE_SET = "QUERY_FIND_REGION_POPUP_VSET_0" ;
	static String VALUE_SET_TEXTFIELD = "//forms:textField[(@name='VSET_QF_FLEX_VALUE_SET_NAME_0')]";
	static String FIND_BUTTON = "//forms:button[(@name='QUERY_FIND_FIND_0')]";	
}
