
public interface Forms_BasicMain {
	static final String Find_JOURNAL_BATCHES = "BATCHES_QF";
	static final String POST_JOURNALS = "BATCHES" ;
	static final String ACCOUNT_INQUIRY = "BATCHES" ;

}
