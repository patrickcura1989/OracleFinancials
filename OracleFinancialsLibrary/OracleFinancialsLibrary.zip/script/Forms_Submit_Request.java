
public interface Forms_Submit_Request {
	static String PROGRAM_NAME = "//forms:textField[(@name='WORK_ORDER_USER_CONCURRENT_PROGRAM_NAME_%')]";
	static String SUBMIT_BUTTON = "//forms:button[(@name='WORK_ORDER_SUBMIT_0')]";
	static String SCHEDULE_BUTTON = "//forms:button[(@name='WORK_ORDER_SCHEDULE_0')]";
	
}
