
public interface Forms_Find_Requests {
	static String FIND_BUTTON = "//forms:button[(@name='JOBS_QF_FIND_0')]";
	static String SUBMIT_NEW_REQUEST = "//forms:button[(@name='JOBS_QF_NEW_0')]";
}
