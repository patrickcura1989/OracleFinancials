
public interface Forms_Find_Invoices {
   static final String FORM_NAME = "" ;	
   static final String SUPPLIER_NUMBER = "//forms:textField[(@name='INVOICES_QF_VENDOR_NUMBER_%')]" ;
   static final String INVOICE_NUMBER  = "//forms:textField[(@name='INVOICES_QF_INVOICE_NUM_%')]" ;
   static final String FIND_BUTTON = "//forms:button[(@name='INVOICES_QF_FIND_0')]" ;
}
