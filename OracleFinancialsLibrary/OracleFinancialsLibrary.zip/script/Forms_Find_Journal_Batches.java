
public interface Forms_Find_Journal_Batches {
	
	static final String FIND_BTN = "//forms:button[(@name='BATCHES_QF_FIND_0')]" ;

}
