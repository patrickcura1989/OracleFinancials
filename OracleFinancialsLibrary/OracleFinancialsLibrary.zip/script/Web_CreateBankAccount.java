
public interface Web_CreateBankAccount {
	public static String BANK_NAME = "/web:window[@title='Create Bank Account']/web:document[@index='0']/web:form[@id='DefaultFormName']/web:input_text[@id='BankNameSelect']";
	public static String BRANCH_NAME = "/web:window[@title='Create Bank Account']/web:document[@index='0']/web:form[@id='DefaultFormName']/web:input_text[@id='BranchNameSelect']";
	public static String ACCOUNT_NUMBER = "/web:window[@title='Create Bank Account']/web:document[@index='0']/web:form[@id='DefaultFormName']/web:input_text[@id='AcctNumber']";
	public static String ACCOUNT_NAME = "/web:window[@title='Create Bank Account']/web:document[@index='0']/web:form[@id='DefaultFormName']/web:input_text[@id='AcctName']";
	public static String APPLY_BUTTON = "/web:window[@title='Create Bank Account']/web:document[@index='0']/web:form[@id='DefaultFormName']/web:button[@id='Apply_uixr']";
	
}
