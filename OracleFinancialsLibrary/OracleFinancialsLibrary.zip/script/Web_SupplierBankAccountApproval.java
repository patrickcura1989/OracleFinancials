
public interface Web_SupplierBankAccountApproval {
	public static final String BANK_FORM_URL = "";
	
	
}
