
public interface Forms_User {
	static String WINDOW_NAME = "//forms:window[(@name='USER_WINDOW')]";
	static String USERNAME = "//forms:textField[(@name='USER_USER_NAME_0')]";
	static String END_DATE = "//forms:textField[(@name='USER_END_DATE_0')]";
	static String PASSWORD = "//forms:textField[(@name='USER_USER_PASSWORD_0')]";
	static String STATUS = "//forms:textField[(@name='USER_USER_STATUS_0')]";
	static final String NONE_RADIO_BUTTON= "";
	static final String RESPONSIBILITY = "" ;
	static final String APPLICATION = "" ;
	static final String EFFECTIVE_DATE_TO = "" ;
	
}
