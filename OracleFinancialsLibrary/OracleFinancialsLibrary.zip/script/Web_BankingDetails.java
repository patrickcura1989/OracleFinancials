
public interface Web_BankingDetails {
	public static String ACCOUNT_ASSIGNMENT_TEXTBOX = "/web:window[@title='Bank Accounts']/web:document[@index='0']/web:form[@id='DefaultFormName]/web:input_text[@id='sitesList']";
	public static String GO_BUTTON = "/web:window[@title='Bank Accounts']/web:document[@index='0']/web:form[@id='DefaultFormName']/web:button[@id='goButton']"; 
	public static String CREATE_BUTTON = "/web:window[@title='Bank Accounts']/web:document[@index='0']/web:form[@id='DefaultFormName']/web:button[@id='CreateBankAccount111']"; 
	public static String SAVE_BUTTON = "/web:window[@title='Bank Accounts']/web:document[@index='0']/web:form[@id='DefaultFormName']/web:button[@id='apply_uixr']";
	public static String HOME_LINK = "/web:window[@title='Bank Accounts']/web:document[@index='0']/web:a[@text='Home']";
	public static String BANKING_DETAILS = "" ;	
	static final  String INCREASE_PRIORITY = "" ;

}
