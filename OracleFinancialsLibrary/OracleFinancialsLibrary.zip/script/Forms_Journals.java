public interface Forms_Journals {
	static String NAME = "HEADER";
	static String HEADER_NAME = "//forms:textField[(@name='HEADER_NAME_%')]";
	static String LINE_NUM = "//forms:textField[(@name='LINES_JE_LINE_NUM_%')]";
	static String ACCOUNT_NUM = "//forms:textField[(@name='LINES_ACCOUNTING_FLEXFIELD_%')]";
	static String DEBIT = "//forms:textField[(@name='LINES_ENTERED_DR_%')]";
	static String CREDIT = "//forms:textField[(@name='LINES_ENTERED_CR_%')]";
	static String DESCRIPTION = "//forms:textField[(@name='LINES_DESCRIPTION_%')]";
	static String APPROVE_BUTTON = "//forms:button[(@name='CONTROL_HEADER_APPROVE_0')]";
}
