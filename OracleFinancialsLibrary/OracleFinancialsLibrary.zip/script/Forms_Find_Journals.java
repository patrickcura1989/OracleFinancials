
public interface Forms_Find_Journals {
	static String NEW_BATCH_BUTTON = "//forms:button[(@name='FOLDER_QF_NEW_BATCH_0')]";
	
	
}
