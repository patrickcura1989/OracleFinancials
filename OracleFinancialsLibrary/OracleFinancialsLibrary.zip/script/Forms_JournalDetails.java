
public interface Forms_JournalDetails extends Forms_Account_Inquiry_ACC {
	static final String BATCH = "//forms:textField[(@name='JOURNALS_BATCH_NAME_%')]" ;

}
