
public interface Forms_Responsibilities {

	static String CORP_PAYABLES_TEAM_LEADER = "CORP Payables Team Leader";
	static String ACC_AR_FINANCE = "ACC AR Finance";
	static String All_Entity_GL_Super_User = "All Entity GL Super User" ;
}
