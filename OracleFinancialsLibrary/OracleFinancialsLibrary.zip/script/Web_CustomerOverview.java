
public interface Web_CustomerOverview {
	static String VIEW_DETAILS = "/web:window[@index='2' or @title='Customer Overview']/web:document[@index='0']/web:img[@alt='View Details' or @index='66' or @src='https://app-layer-oracleebs-test.ds.acc.co.nz:4476/OA_MEDIA/detailsicon_enabled.gif']";
}
