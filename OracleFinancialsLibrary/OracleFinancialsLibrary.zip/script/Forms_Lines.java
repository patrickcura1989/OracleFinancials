
public interface Forms_Lines {
	static String NAME = "TLIN_LINES";
	static String DESCRIPTION = "//forms:textField[(@name='TLIN_LINES_DESCRIPTION_%')]";
	static String QUANTITY = "//forms:textField[(@name='TLIN_LINES_QUANTITY_%')]";
	static String UNIT_PRICE = "//forms:textField[(@name='TLIN_LINES_UNIT_SELLING_PRICE_%')]";
	static String DISTRIBUTIONS_BUTTON = "//forms:button[(@name='TLIN_LINES_LINE_ACCOUNTING_0')]";
	static String DISTRIBUTIONS_TITLE = "TACCOUNTS";
}
