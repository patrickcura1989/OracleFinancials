
public interface Web_SupplierBankAccountRequest {
	static final String NEW_BANK_ACCOUNT_URL = "/web:window[@title='Notification Details']/web:document[@index='0']/web:a[@text='New Bank Account URL']";
	static final String GO_BUTTON = "/web:window[@title='Search Supplier Bank Account Assignment']/web:document[@index='0']/web:form[@id='DefaultFormName']/web:button[@id='Go']";
	
	
}
