
public interface Forms_Batch {
	static String BATCH_NAME = "//forms:textField[(@name='BATCH_NAME_0')]";
	static String JOURNAL_BUTTON = "//forms:button[(@name='BATCH_GO_HEADER_0')]";
	static String APPROVAL_STATUS = "//forms:textField[(@name='BATCH_SHOW_APPROVAL_STATUS_0')]";
}
