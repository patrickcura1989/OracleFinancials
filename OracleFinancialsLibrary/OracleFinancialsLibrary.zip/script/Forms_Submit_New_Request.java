
public interface Forms_Submit_New_Request {
	static String OK_BUTTON = "//forms:button[(@name='WHAT_TYPE_OK_0')]";
}
