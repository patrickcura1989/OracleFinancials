
public interface Forms_Select_Invoice {
   static final String INVOICE_NUMBER = "//forms:textField[(@name='ADJ_INV_PAY_INVOICE_NUM_%')]" ;
   static final String INVOICE_OVERVIEW = "//forms:button[(@name='ADJ_IP_CTRL_INVOICE_OVERVIEW_BUTTON_0')]";
}
