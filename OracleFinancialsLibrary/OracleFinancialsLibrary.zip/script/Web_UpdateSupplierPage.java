
public interface Web_UpdateSupplierPage {
	static final String PAGE_NAME  = "/web:window[@title='Update*']";
	static final String ADDRESS_BOOK_LINK  = "/web:window[@title='Update*']/web:document[@index='0']/web:a[@text='Address Book']";
	static final String SAVE_BUTTON = "/web:window[@title='Update*']/web:document[@index='0']/web:form[@id='DefaultFormName']/web:button[@id='btnSave']";
	static final String PAYMENT_DETAILS_LINK = "/web:window[@title='Payment Details']/web:document[@index='0']/web:a[@text='SelectedPayment Details']" ;
	static final String ADDRESS_LINK = "" ;
	static final String BANKING_DETAILS = "" ;
	
}
