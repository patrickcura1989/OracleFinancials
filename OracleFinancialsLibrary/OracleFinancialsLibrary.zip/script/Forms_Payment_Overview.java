
public interface Forms_Payment_Overview {
   static final String FORM_NAME = "" ;	
   static final String PAYMENT_METHOD = "//forms:button[(@name='INVOICE_PAYMENTS_BUTTON_0')]" ;
   static final String AMOUNT = "//forms:textField[(@name='PAYMENT_AMOUNT_0')]" ;
   static final String PAID_TO_NAME = "" ;
   static final String NUMBER = "" ;
   static final String AMOUNT_PAID = "" ;	
   static final String DOCUMENT_NUMBER= "" ;
   
}
