
public interface Web_AbstractWin {

	static final String HOME_LINK = "/web:window[ @title='*']/web:document[@index='0']/web:a[@text='Home']" ;
}
