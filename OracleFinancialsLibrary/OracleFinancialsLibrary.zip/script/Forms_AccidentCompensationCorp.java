
public interface Forms_AccidentCompensationCorp {
	static String WINDOW_NAME = "FIRST"; 
	static String OPEN_DIALOG = "//forms:textField[(@name='FIRST_FIRST_OPEN_PERIOD_%')]";
	static String OPEN_BUTTON = "//forms:button[(@name='CONTROL_OPEN_TARGET_PERIOD_0')]";	
}
