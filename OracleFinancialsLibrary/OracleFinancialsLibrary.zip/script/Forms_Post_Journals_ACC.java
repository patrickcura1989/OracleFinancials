
public interface Forms_Post_Journals_ACC {
  
	static final String POST_BTN = "//forms:button[(@name='CONTROL_POST_BUTTON_0')]";
}
