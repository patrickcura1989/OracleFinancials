
public interface Web_SearchSupplierBankAccountAssignment {
	static final String SUPPLIER_NUMBER = "/web:window[@title='Search Supplier Bank Account Assignment']/web:document[@index='0']/web:form[@id='DefaultFormName']/web:input_text[@id='SupplierNumber']";
	static final String SHOW_LINK = "/web:window[@title='Search Supplier Bank Account Assignment']/web:document[@index='0']/web:a[@text='Show']";
	static final String GO_BUTTON = "/web:window[@title='Search Supplier Bank Account Assignment']/web:document[@index='0']/web:form[@id='DefaultFormName']/web:button[@id='Go']";
	static final String HOME_LINK = "/web:window[@title='Search Supplier Bank Account Assignment']/web:document[@index='0']/web:a[@text='Home']"; 

}
