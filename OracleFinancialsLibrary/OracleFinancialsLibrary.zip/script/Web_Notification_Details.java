
public interface Web_Notification_Details {
	static final String EDIT_INVOICE_LINES_LINK = "/web:window[@index='0' or @title='Notification Details']/web:document[@index='0']/web:a[@text='Click here to view/edit Invoice Lines']";
	static final String APPROVE_BUTTON = "/web:window[@title='Notification Details']/web:document[@index='0']/web:form[@id='DefaultFormName' or @name='DefaultFormName']/web:button[@value='Approve']";
	static final String BANK_FORM_URL = "/web:window[@title='Notification Details']/web:document[@index='0']/web:a[@text='Bank Form URL']"; 
	static final String FORM_URL = "" ;
	static final String OK_BUTTON = "" ;

}
