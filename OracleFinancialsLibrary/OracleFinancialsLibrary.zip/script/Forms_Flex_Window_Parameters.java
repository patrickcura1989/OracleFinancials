
public interface Forms_Flex_Window_Parameters {
	static String INVOICE_NUMBER = "Invoice Number"; 
	static String FROM_ENTERED_DATE = "From Entered Date" ;
	static String TO_ENTERED_DATE = "To Entered Date" ;
}
