
public interface Forms_Open_And_Close_Periods {
	static String NAME = "LATEST";
	static String OPEN_PERIOD_BUTTON = "//forms:button[(@name='CONTROL_OPEN_NEXT_PERIOD_0')]";
	static String STATUS_TEXTFIELD_1 = "//forms:textField[(@name='PREVIOUS_SHOW_STATUS_1')]";
	static String PERIOD_TEXTFIELD_1 = "//forms:textField[(@name='PREVIOUS_PERIOD_NAME_1')]";
}
