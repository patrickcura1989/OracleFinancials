
public interface Forms_UniversalSearch {
	static String FIND_LIST = "ASTLSGEN_MAIN_VIEWPORT_0";
	static String RADIO_BUTTON_ACCOUNT = "ASTLSKEY_QUICK_SEARCH_SELECT_RADIO_BUTTON5_0";
	static String TEXT_FIELD_ACCOUNT = "//forms:textField[(@name='ASTLSKEY_QUICK_SEARCH_ACCOUNT_NUM_%')]";
	static String SEARCH = "//forms:button[(@name='ASTLSGEN_MAIN_SEARCH_0')]";
	static String OK = "//forms:button[(@name='ASTLSGEN_MAIN_OK_0')]";
}
