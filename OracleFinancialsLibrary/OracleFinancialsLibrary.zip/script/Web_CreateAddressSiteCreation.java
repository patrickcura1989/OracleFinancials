
public interface Web_CreateAddressSiteCreation {
	
	static final String APPLY_BUTTON = "/web:window[@title='Create Address: Site Creation']/web:document[@index='0']/web:form[@id='DefaultFormName']/web:button[@id='applyBtn']";
	static final String SELECT_CHECKBOX = "/web:window[@title='Create Address: Site Creation']/web:document[@index='0']/web:form[@id='DefaultFormName']/web:input_checkbox[@index='%']" ;

}
