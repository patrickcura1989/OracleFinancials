
public interface EmailConfiguration {
  static final String URL = "https://wlgcasarray.ds.acc.co.nz/ews/Exchange.asmx" ;
  static final String USER_NAME = "Automation.Test@acc.co.nz" ;
  static final String PASSWORD = "Password05" ;
}
