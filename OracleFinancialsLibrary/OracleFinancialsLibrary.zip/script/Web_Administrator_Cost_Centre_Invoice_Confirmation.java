
public interface Web_Administrator_Cost_Centre_Invoice_Confirmation {
	static final String CONFIRM_BUTTON = "/web:window[@index='0' or @title='Administrator Cost Centre Invoice Confirmation']/web:document[@index='0']/web:form[@id='DefaultFormName' or @name='DefaultFormName' or @index='0']/web:button[@id='Confirm_uixr' or @value='Confirm']";
	static final String REJECT_BUTTON = "/web:window[@index='0' or @title='Administrator Cost Centre Invoice Confirmation']/web:document[@index='0']/web:form[@id='DefaultFormName' or @name='DefaultFormName' or @index='0']/web:button[@id='Reject_uixr' or @value='Reject']";
	static final String NOTE_TEXT_AREA = "/web:window[@index='0' or @title='Administrator Cost Centre Invoice Confirmation']/web:document[@index='0']/web:form[@id='DefaultFormName' or @name='DefaultFormName' or @index='0']/web:textarea[@id='Note' or @name='Note' or @index='0']";	
}
