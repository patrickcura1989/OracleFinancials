
public interface Forms_Requests {
	static String JOB_PHASE_STATUS = "//forms:textField[(@name='JOBS_PHASE_0')]";	
	static String JOB_JD = "//forms:textField[(@name='JOBS_REQUEST_ID_$')]";
	static String VIEW_OUTPUT_BUTTON = "//forms:button[(@name='JOBS_VIEW_REPORT_0')]";
}
