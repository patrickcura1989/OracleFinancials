
public interface Web_CreateAddressConfirmDetails {
	static String SELECT_CHECKBOX= "/web:window[@title='Create Address: Site Creation']/web:document[@index='0']/web:form[@id='DefaultFormName' or @name='DefaultFormName' or @index='0']/web:input_checkbox[@id='M__Id' or @name='N10:selected:0' or @index='0']";
	static String APPLY_BUTTON = "/web:window[@title='Create Address: Site Creation']/web:document[@index='0']/web:form[@id='DefaultFormName' or @name='DefaultFormName' or @index='0']/web:button[@id='applyBtn_uixr' or @value='A<SPAN class=xq style=&quot;BACKGROUND-IMAGE: none; BACKGROUND-COLOR: transparent&quot; Oracle_OS_WebDOM_ElementID=&quot;True&quot;>p</SPAN>ply' or @index='5']";

}
