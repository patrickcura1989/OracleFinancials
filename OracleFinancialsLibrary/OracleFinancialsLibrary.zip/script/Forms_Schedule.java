
public interface Forms_Schedule {
	static String RADIO_BUTTON = "SCHEDULE_SCHEDULE_TYPE_PERIODICALLY_0";
	static String START_AT = "//forms:textField[(@name='SCHEDULE_START_DATE_0')]";
	static String END_AT = "//forms:textField[(@name='SCHEDULE_END_DATE_0')]";
	static String LIST_SCHEDULE_INTERVAL = "SCHEDULE_INTERVAL_0";
	static String OK_BUTTON = "//forms:button[(@name='SCHEDULE_OK_0')]";
}
