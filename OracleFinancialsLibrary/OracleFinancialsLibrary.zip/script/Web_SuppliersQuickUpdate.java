
public interface Web_SuppliersQuickUpdate {
	public static String BANKING_DETAILS_NAV_LINK = "/web:window[@title='Update TEST T3017558 - T3017558: Quick Update']/web:document[@index='0']/web:a[@text='Banking Details' or @href='javascript:_submitNav(&apos;DefaultFormName&apos;,&apos;https%3A//app-layer-oracleebs-test.ds.acc.co.nz%3A4475/OA_HTML/OA.jsp%3Fpage%3D/oracle/apps/pos/sbd/webui/ByrMainPG%26retainAM%3DY%26_ti%3D606267237%26oapc%3D9%26OAMC%3D79928_67_0%26menu%3DY%26oaMenuLevel%3D4%26oas%3DgWx4k8pWDgefXn_8SNTwyg..&apos;)' or @index='11']";
}
