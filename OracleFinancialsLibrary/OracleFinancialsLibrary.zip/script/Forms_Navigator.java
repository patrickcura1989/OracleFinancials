
public interface Forms_Navigator {		
	static String TRANSACTIONS_VIEW_AND_ENTER = "Transactions View and Enter";
	static String TRANSACTIONS_VIEW_AND_ENTER_BATCHES = "Transactions View and Enter|Batches";
	
	static String INVOICES = "Invoices";
	static String INVOICES_ENTRY = "Invoices|Entry";
	static String INVOICES_ENTRY_INVOICES = "Invoices|Entry|Invoices";
	
	static String OTHER = "Other";
	static String OTHER_REQUESTS = "Other|Requests";
	static String OTHER_REQUESTS_RUN = "Other|Requests|Run";
}
