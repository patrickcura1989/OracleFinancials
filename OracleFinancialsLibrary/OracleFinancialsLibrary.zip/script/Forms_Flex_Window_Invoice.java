
public interface Forms_Flex_Window_Invoice {
	static String BARCODE = "Barcode";
	static String ADMINISTRATION_CC = "Administration CC";
	static String SPECIAL_DFA_REQUIRED ="Special DFA Required";
	static String SUBMIT_CODING_WORKFLOW = "Submit Coding Workflow";
}
