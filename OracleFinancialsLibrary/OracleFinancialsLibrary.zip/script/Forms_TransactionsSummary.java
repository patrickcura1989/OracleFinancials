
public interface Forms_TransactionsSummary {
	static String NAME = "//forms:window[(@name='TGW_FOLDER')]";
	static String NUMBER = "//forms:textField[(@name='TGW_HEADER_TRX_NUMBER_0')]";
	static String ADJUST_BUTTON = "//forms:button[(@name='TGW_HEADER_SUMMARY_ADJUST_0')]";
	
}
