
public interface Forms_Find_Account {

	static final String OK_BTN = "" ;
}
