
public interface Forms_Segment_Values {
	static String VALUE_DF = "//forms:textField[(@name='VALUE_DF_%')]";
}
