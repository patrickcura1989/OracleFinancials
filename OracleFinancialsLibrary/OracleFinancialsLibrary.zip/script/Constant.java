
public interface Constant {
	static final String USERNAME = "TANK" ;
	static final String PASSWORD = "may123456" ;
	static final String USERNAME_APPROVER = "QUAYLEC" ;
	static final String USERNAME_APPROVER_PWD = "april1234" ;
	static final String USERNAME_MANAGER = "YOUNGLE" ;
	static final String USERNAME_PWD_MANAGER  = "APR2345" ;
	static final String USERNAME_SUPPLIER_APPROVER = "SMITHA";
	static final String USERNAME_SUPPLIER_APPROVER_PWD = "apr12345";
	static final String USERNAME_BANK_SETUP = "SMITHAME";
	static final String USERNAME_BANK_SETUP_PWD = "apr12345";
	static final String USERNAME_SUPPLIER_BANK_APPROVE = "SMITHARI";
	static final String USERNAME_SUPPLIER_BANK_PWD = "apr12345";
	
	static final int WAIT = 60 ;
	static final String DOM_ID = "/web:document[@index='0']" ;
    static final String FLEX_WINDOW = "//forms:flexWindow";
    static final String ORACLE_BASE_URL = "https://app-layer-oracleebs-test.ds.acc.co.nz:4475";
    static final String ORACLE_URL = ORACLE_BASE_URL + "/OA_HTML/RF.jsp?function_id=30290&resp_id=-1&resp_appl_id=-1&security_group_id=0&lang_code=US&params=Jknr8tW4I..B4KKQLHC-AA&oas=04JcU4po2tgHxnohZKaQCA.." ;
    static final String MAIN_WINDOW = "//forms:window[(@name='NAVIGATOR')]" ;
    static final String FORMS_TAB = "//forms:tab[(@name='%')]";
    static final String INVOICES_MAIN_WINDOW = "//forms:window[(@name='INVOICES_SUM_FOLDER_WINDOW')]";
    static final long ONE_MINUTE_IN_MILLIS=60000;//millisecs
    
}
