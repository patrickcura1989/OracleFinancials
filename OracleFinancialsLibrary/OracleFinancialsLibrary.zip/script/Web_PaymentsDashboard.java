
public interface Web_PaymentsDashboard {
   static final String PAGE_NAME = "/web:window[@title='Payments Dashboard']" ; 	
   static final String SUBMIT_SINGLE_PAYMENT_PROCESS_REQUEST_LINK = "/web:window[@title='Payments Dashboard']/web:document[@index='0']/web:a[@text='Submit Single Payment Process Request']" ;
}
