
public interface Web_Submit_Payment_Process_Request {
 
	static final String PAGE_NAME = "/web:window[@title='Submit Payment Process Request']" ;
	static final String PAYMENT_PROCESS_REQUEST_NAME = "/web:window[@title='Submit Payment Process Request']/web:document[@index='0']/web:form[@id='DefaultFormName']/web:input_text[@id='CheckrunName']" ;
	static final String USE_TEMPLATE = "/web:window[@title='Submit Payment Process Request']/web:document[@index='0']/web:form[@id='DefaultFormName']/web:input_text[@id='TemplateName']" ;
	static final String SUBMIT_BUTTON = "/web:window[@title='Submit Payment Process Request']/web:document[@index='0']/web:form[@id='DefaultFormName']/web:button[@id='Submit_uixr']" ;
	static final String PAY_GROUPS_SPECIFY = "" ;
	static final String PAY_GROUPS_ADD = "" ;
}
